function salvar() {
    // 1º coletar os campos
    let nome = document.getElementById("nome").value
    let email = document.getElementById("email").value
    let cpf = document.getElementById("cpf").value

    console.log(nome)
    console.log(email)
    console.log(cpf)

    // 2º validação
    // se o campo estiver vazio, exibe o alerta de erro
    // quero comparar se o nome é igual a uma string vazia ("")
    if(nome == "") {
        // exibe o alerta de erro
        alert("Preencha todos os campos!")
    }

    // 3º exibir o alerta
}